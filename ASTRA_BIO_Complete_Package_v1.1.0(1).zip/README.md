# ASTRA-BIO Complete Package v1.1.0

Three delivery paths, one package.

---

## 01_Web_App_FastAPI_Docker/

Full-stack web application with NASA OSDR integration, PWA install support, and production HTTPS deployment.

| File | Purpose |
|---|---|
| `docker-compose.yml` | Local development (port 8000) |
| `docker-compose.prod.yml` | Production nginx + Let's Encrypt (HTTPS) |
| `deploy/docker-compose.caddy.yml` | Simpler Caddy alternative |
| `scripts/init-letsencrypt.sh` | One-command HTTPS setup |
| `static/` | Dark-themed web UI (Chart.js), now PWA-installable |

**Run:** `docker compose up --build` → http://localhost:8000

**Production:** `DOMAIN=astra.yourdomain.com EMAIL=you@example.com bash scripts/init-letsencrypt.sh`

**Install on Android (PWA):** Open the live HTTPS URL in Chrome → "Install app" → fullscreen app icon.

---

## 02_Android_App_Chaquopy/

Fully offline native Android APK. Python 3.11 + NumPy + SciPy embedded via Chaquopy.

| File | Purpose |
|---|---|
| `app/build.gradle` | Chaquopy plugin config, pip dependencies |
| `app/src/main/python/astra_engine.py` | Complete statistics engine (numpy+scipy only) |
| `app/src/main/python/osdr_query.py` | stdlib-only NASA OSDR client |
| `app/src/main/java/.../MainActivity.kt` | Native UI with MPAndroidChart |

**Build:** Open in Android Studio → Run ▶ (first build downloads Python runtime, ~few hundred MB)

**Release:** `./gradlew assembleRelease`

**Offline:** Demo analysis works with zero internet.

---

## 03_Standalone_Python_Model/

Original single-file engine. No web server, no dependencies beyond standard scientific Python.

| File | Purpose |
|---|---|
| `astra_bio_working_model.py` | Self-contained script; run `python astra_bio_working_model.py` |
| `astra_bio_analysis.png` | Sample 4-panel output |
| `astra_bio_report.md` | Sample markdown report |

---

## Quick path guide

| Goal | Path | Effort |
|---|---|---|
| Test/demo on your laptop | `03_Standalone_Python_Model/` | 2 min |
| Deploy for team/institution | `01_Web_App_FastAPI_Docker/` | 30 min |
| Installable on phones (no store) | `01_Web_App_FastAPI_Docker/` + PWA | 30 min |
| Publish on Google Play | `02_Android_App_Chaquopy/` | hours (build + store setup) |
| Fully offline on Android | `02_Android_App_Chaquopy/` | hours |

---

## License notes

- ASTRA-BIO code: free to use as you see fit
- Chaquopy (Android): free for open-source/non-commercial; commercial apps require a license from chaquo.com
- NASA OSDR data: public domain

---

*Package generated: 2026-11-03*
*ASTRA-BIO Comparative Research Engine v1.1.0*
