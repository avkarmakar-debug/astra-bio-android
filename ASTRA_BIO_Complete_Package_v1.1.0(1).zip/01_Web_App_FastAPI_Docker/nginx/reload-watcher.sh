#!/bin/sh
# Start nginx, then watch the certificate file and reload when certbot renews it.
set -e

CERT=/etc/letsencrypt/live/${DOMAIN}/fullchain.pem

nginx -g 'daemon off;' &
echo "[watcher] nginx started for ${DOMAIN}"

last=$(stat -c %Y "$CERT" 2>/dev/null || echo 0)
while true; do
    sleep 60
    cur=$(stat -c %Y "$CERT" 2>/dev/null || echo 0)
    if [ "$cur" != "$last" ]; then
        last=$cur
        echo "[watcher] certificate changed — reloading nginx"
        nginx -s reload
    fi
done
