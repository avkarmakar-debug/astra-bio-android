#!/usr/bin/env bash
# One-time setup: obtain the first Let's Encrypt certificate and start the stack.
#
#   DOMAIN=astra.yourdomain.com EMAIL=you@example.com bash scripts/init-letsencrypt.sh
#   STAGING=1 ...   # use Let's Encrypt staging while testing (avoids rate limits)
#
# Prereqs: DNS A record for DOMAIN already points at this machine; ports 80/443 open.

set -euo pipefail
cd "$(dirname "$0")/.."

: "${DOMAIN:?Set DOMAIN, e.g. astra.yourdomain.com}"
: "${EMAIL:?Set EMAIL for expiry notices}"
STAGING=${STAGING:-0}

echo "==> 1/5 Preparing directories"
mkdir -p certbot/www certbot/conf/live

echo "==> 2/5 Starting temporary HTTP nginx (needed for the ACME challenge)"
sed "s/__DOMAIN__/${DOMAIN}/g" nginx/http-only.conf.template > nginx/default.conf
docker compose -f docker-compose.prod.yml up -d

echo "==> 3/5 Requesting certificate from Let's Encrypt"
STAGING_ARG=""
[ "$STAGING" = "1" ] && STAGING_ARG="--staging"
# shellcheck disable=SC2086
docker compose -f docker-compose.prod.yml run --rm certbot certonly \
    --webroot -w /var/www/certbot \
    -d "${DOMAIN}" \
    --email "${EMAIL}" \
    --agree-tos --no-eff-email \
    ${STAGING_ARG} \
    --keep-until-expiring

echo "==> 4/5 Switching to HTTPS config"
sed "s/__DOMAIN__/${DOMAIN}/g" nginx/default.conf.template > nginx/default.conf
docker compose -f docker-compose.prod.yml exec nginx nginx -s reload

echo "==> 5/5 Ensuring the stack is up"
docker compose -f docker-compose.prod.yml up -d

echo
echo "Done. Your app should be live at:  https://${DOMAIN}"
echo "Certbot will renew automatically; nginx reloads on its own."
