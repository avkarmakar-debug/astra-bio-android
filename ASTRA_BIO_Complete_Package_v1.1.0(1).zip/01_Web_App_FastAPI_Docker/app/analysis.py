"""
ASTRA-BIO Comparative Analysis Engine.

Supports:
  - phenotypes  : growth, MIC, biofilm (scalar group comparisons)
  - transcriptomics / proteomics : per-feature differential abundance (t-test,
                  log2 fold change, Cohen's d, BH-FDR)
  - metabolomics: per-metabolite comparisons + optional pathway-level summary
                  and PCA for exploratory multivariate analysis
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests


# ---------------------------------------------------------------------------
# Result containers
# ---------------------------------------------------------------------------
@dataclass
class ComparisonResult:
    feature: str
    earth_mean: float
    space_mean: float
    difference: float
    fold_change: float
    log2_fold_change: float
    pct_change: float
    cohens_d: float
    effect_size: str
    t_statistic: float
    p_value: float
    p_value_adj: float
    ci95_lower: float
    ci95_upper: float
    significant: bool
    n_earth: int
    n_space: int

    def to_dict(self) -> Dict:
        return asdict(self)


def _effect_size_label(d: float) -> str:
    a = abs(d)
    if a < 0.2:
        return "negligible"
    if a < 0.5:
        return "small"
    if a < 0.8:
        return "medium"
    return "large"


# ---------------------------------------------------------------------------
# Core per-feature comparison
# ---------------------------------------------------------------------------
def compare_feature(earth: np.ndarray, space: np.ndarray, name: str) -> ComparisonResult:
    earth = np.asarray(earth, dtype=float)
    space = np.asarray(space, dtype=float)
    earth = earth[~np.isnan(earth)]
    space = space[~np.isnan(space)]

    e_mean, s_mean = earth.mean(), space.mean()
    e_std, s_std = earth.std(ddof=1), space.std(ddof=1)

    pooled = np.sqrt(((len(earth) - 1) * e_std**2 + (len(space) - 1) * s_std**2) /
                     (len(earth) + len(space) - 2))
    d = (s_mean - e_mean) / pooled if pooled > 0 else 0.0

    fc = s_mean / e_mean if e_mean != 0 else np.nan
    l2fc = np.log2(fc) if fc and fc > 0 else 0.0
    pct = (fc - 1) * 100 if np.isfinite(fc) else np.nan

    t_stat, p_val = stats.ttest_ind(space, earth, equal_var=False)

    diff = s_mean - e_mean
    se = pooled * np.sqrt(1 / len(earth) + 1 / len(space)) if pooled > 0 else 0.0
    if se > 0:
        lo, hi = stats.t.interval(0.95, len(earth) + len(space) - 2, loc=diff, scale=se)
    else:
        lo = hi = diff

    return ComparisonResult(
        feature=name,
        earth_mean=float(e_mean), space_mean=float(s_mean),
        difference=float(diff), fold_change=float(fc), log2_fold_change=float(l2fc),
        pct_change=float(pct), cohens_d=float(d), effect_size=_effect_size_label(d),
        t_statistic=float(t_stat), p_value=float(p_val),
        p_value_adj=float(p_val),  # corrected later in batch
        ci95_lower=float(lo), ci95_upper=float(hi),
        significant=bool(p_val < 0.05),
        n_earth=int(len(earth)), n_space=int(len(space)),
    )


def apply_fdr_correction(results: List[ComparisonResult]) -> List[ComparisonResult]:
    """Benjamini-Hochberg correction across a list of results."""
    if not results:
        return results
    _, p_adj, _, _ = multipletests([r.p_value for r in results], method="fdr_bh")
    for r, pa in zip(results, p_adj):
        r.p_value_adj = float(pa)
        r.significant = bool(pa < 0.05)
    return results


# ---------------------------------------------------------------------------
# Data-type-specific pipelines
# ---------------------------------------------------------------------------
class ComparativeAnalysisEngine:
    """Main scientific backend."""

    def compare_phenotypes(
        self, earth_df: pd.DataFrame, space_df: pd.DataFrame,
        parameters: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """Scalar phenotype comparison (growth, MIC, biofilm...)."""
        if parameters is None:
            skip = {"sample_id", "condition"}
            parameters = [c for c in earth_df.columns
                          if c in space_df.columns and c not in skip]
        results = [compare_feature(earth_df[p].values, space_df[p].values, p)
                   for p in parameters]
        apply_fdr_correction(results)
        return pd.DataFrame([r.to_dict() for r in results])

    def differential_abundance(
        self, earth_df: pd.DataFrame, space_df: pd.DataFrame,
        id_column: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Per-feature differential analysis for transcriptomics / proteomics /
        metabolomics matrices in the standard omics layout:
        rows = features (genes/proteins/metabolites), columns = samples.

        ``id_column`` names the feature-identifier column (e.g. 'gene',
        'protein', 'metabolite'); if None, the first non-numeric column is
        used, otherwise row indices are used.
        """
        if id_column is None:
            for cand in ("gene", "protein", "metabolite", "feature",
                         "compound", "id", "name"):
                if cand in earth_df.columns:
                    id_column = cand
                    break

        if id_column and id_column in earth_df.columns:
            names = earth_df[id_column].astype(str).tolist()
            e_num = earth_df.drop(columns=[id_column]).select_dtypes("number")
            s_num = space_df.drop(columns=[id_column], errors="ignore").select_dtypes("number")
        else:
            names = earth_df.index.astype(str).tolist()
            e_num = earth_df.select_dtypes("number")
            s_num = space_df.select_dtypes("number")

        # Align numeric sample columns on position (both groups have the same
        # number of sample columns in the standard layout).
        n_e, n_s = e_num.shape[1], s_num.shape[1]
        results = []
        for i, name in enumerate(names):
            e_vals = e_num.iloc[i].values.astype(float)
            s_vals = s_num.iloc[i].values.astype(float) if n_s else np.array([])
            if len(s_vals) == 0:
                continue
            results.append(compare_feature(e_vals, s_vals, str(name)))

        apply_fdr_correction(results)
        return pd.DataFrame([r.to_dict() for r in results])

    # ------------------------- metabolomics extras -------------------------
    def metabolite_summary(self, diff_df: pd.DataFrame) -> Dict:
        """High-level summary of a metabolomics comparison."""
        sig = diff_df[diff_df["significant"]]
        return {
            "n_metabolites": int(len(diff_df)),
            "n_significant": int(len(sig)),
            "n_increased": int((sig["log2_fold_change"] > 0).sum()),
            "n_decreased": int((sig["log2_fold_change"] < 0).sum()),
            "median_abs_effect": float(sig["cohens_d"].abs().median()) if len(sig) else 0.0,
        }

    def pca(self, earth_df: pd.DataFrame, space_df: pd.DataFrame,
            n_components: int = 2) -> Dict:
        """Exploratory PCA across both groups."""
        numeric_cols = earth_df.select_dtypes(include=[np.number]).columns
        X_e = earth_df[numeric_cols].values
        X_s = space_df[numeric_cols].values
        X = np.vstack([X_e, X_s])
        X = np.nan_to_num((X - X.mean(0)) / (X.std(0) + 1e-9))
        try:
            from sklearn.decomposition import PCA
            pca = PCA(n_components=n_components)
            scores = pca.fit_transform(X)
            ev = pca.explained_variance_ratio_.tolist()
        except ImportError:  # numpy SVD fallback
            Xc = X - X.mean(0)
            _, s, vt = np.linalg.svd(Xc, full_matrices=False)
            scores = Xc @ vt[:n_components].T
            ev = (s**2 / (s**2).sum())[:n_components].tolist()
        return {
            "scores": scores.tolist(),
            "labels": ["earth"] * len(X_e) + ["space"] * len(X_s),
            "explained_variance": ev,
        }


# ---------------------------------------------------------------------------
# Sample-data generator (demo / offline mode)
# ---------------------------------------------------------------------------
def generate_sample_data(seed: int = 42) -> Dict[str, pd.DataFrame]:
    """Realistic demo dataset when live OSDR access is unavailable."""
    rng = np.random.default_rng(seed)
    n = 30

    earth_ph = pd.DataFrame({
        "sample_id": [f"Earth_{i:03d}" for i in range(n)],
        "growth_rate": rng.normal(0.45, 0.08, n),
        "MIC": rng.normal(2.0, 0.3, n),
        "biofilm_biomass": rng.normal(0.35, 0.06, n),
        "condition": "Earth_Control",
    })
    space_ph = pd.DataFrame({
        "sample_id": [f"Space_{i:03d}" for i in range(n)],
        "growth_rate": rng.normal(0.38, 0.09, n),
        "MIC": rng.normal(3.2, 0.5, n),
        "biofilm_biomass": rng.normal(0.52, 0.08, n),
        "condition": "Spaceflight",
    })

    # Proteomics: 20 proteins
    proteins = [f"PRO{i:03d}" for i in range(1, 21)]
    earth_prot = pd.DataFrame({"protein": proteins,
                               **{f"E{i:02d}": rng.normal(1.0, 0.3, len(proteins))
                                  for i in range(n)}})
    space_prot = pd.DataFrame({"protein": proteins,
                               **{f"S{i:02d}": rng.normal(1.6, 0.4, len(proteins))
                                  for i in range(n)}})

    # Metabolomics: 25 metabolites
    mets = [f"MET{i:03d}" for i in range(1, 26)]
    earth_met = pd.DataFrame({"metabolite": mets,
                              **{f"E{i:02d}": rng.normal(10, 3, len(mets))
                                 for i in range(n)}})
    space_met = pd.DataFrame({"metabolite": mets,
                              **{f"S{i:02d}": rng.normal(14, 4, len(mets))
                                 for i in range(n)}})

    # Transcriptomics: 8 stress genes
    genes = ["katG", "sodA", "recA", "lexA", "ompF", "acrA", "marR", "soxR"]
    earth_expr = pd.DataFrame({"gene": genes,
                               **{f"E{i:02d}": rng.normal(5.0, 1.0, len(genes))
                                  for i in range(n)}})
    space_expr = pd.DataFrame({"gene": genes,
                               **{f"S{i:02d}": rng.normal(9.0, 1.5, len(genes))
                                  for i in range(n)}})

    return {
        "earth_phenotypes": earth_ph, "space_phenotypes": space_ph,
        "earth_proteomics": earth_prot, "space_proteomics": space_prot,
        "earth_metabolomics": earth_met, "space_metabolomics": space_met,
        "earth_transcriptomics": earth_expr, "space_transcriptomics": space_expr,
    }
