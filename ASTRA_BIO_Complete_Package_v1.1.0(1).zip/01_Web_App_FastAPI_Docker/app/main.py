"""
ASTRA-BIO Comparative Research Engine — FastAPI application.

Endpoints
---------
GET  /                      web UI
GET  /api/health            liveness probe
GET  /api/osdr/datasets     list OSDR dataset accessions
GET  /api/osdr/dataset/{acc}           metadata for one dataset
GET  /api/osdr/dataset/{acc}/files     file records for one dataset
POST /api/analyze/phenotypes           compare scalar phenotype groups
POST /api/analyze/omics                differential abundance (trans/proteo/metabo)
POST /api/analyze/demo                 run full demo on generated sample data
GET  /api/report/demo                  full markdown demo report
"""

from __future__ import annotations

import io
from typing import Dict, List, Optional

import pandas as pd
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from .analysis import ComparativeAnalysisEngine, generate_sample_data
from .osdr_client import OSDRClient, OSDRError
from .report import markdown_report, summary_payload

app = FastAPI(
    title="ASTRA-BIO Comparative Research Engine",
    version="1.1.0",
    description="Spaceflight vs Earth biological comparison platform "
                "(transcriptomics, proteomics, metabolomics, phenotypes).",
)

engine = ComparativeAnalysisEngine()
osdr = OSDRClient()

app.mount("/static", StaticFiles(directory="static"), name="static")


# ---------------------------------------------------------------------------
# UI + health
# ---------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    with open("static/index.html", encoding="utf-8") as f:
        return f.read()


@app.get("/api/health")
async def health() -> Dict[str, str]:
    return {"status": "ok", "service": "astra-bio", "version": "1.1.0"}


# ---------------------------------------------------------------------------
# NASA OSDR integration
# ---------------------------------------------------------------------------
@app.get("/api/osdr/datasets")
async def list_osdr_datasets():
    try:
        return {"datasets": await osdr.list_datasets()}
    except OSDRError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.get("/api/osdr/dataset/{accession}")
async def osdr_dataset(accession: str):
    try:
        return await osdr.get_dataset_metadata(accession)
    except OSDRError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.get("/api/osdr/dataset/{accession}/files")
async def osdr_files(accession: str):
    try:
        return {"files": await osdr.list_files(accession)}
    except OSDRError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.get("/api/osdr/search")
async def osdr_search(organism: Optional[str] = None,
                      spaceflight_only: bool = True):
    """Search sample metadata across OSDR (optionally filtered)."""
    params: Dict[str, str] = {"study.characteristics.organism": organism or ""}
    if spaceflight_only:
        params["study.factor value.spaceflight"] = ""
    try:
        df = await osdr.query_metadata(params)
        return {"n_samples": len(df), "preview": df.head(50).to_dict(orient="records")}
    except OSDRError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


# ---------------------------------------------------------------------------
# Analysis endpoints
# ---------------------------------------------------------------------------
def _read_upload(file: UploadFile) -> pd.DataFrame:
    raw = file.file.read()
    name = file.filename or ""
    try:
        if name.endswith((".xlsx", ".xls")):
            return pd.read_excel(io.BytesIO(raw))
        if name.endswith(".json"):
            return pd.read_json(io.BytesIO(raw))
        return pd.read_csv(io.BytesIO(raw))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not parse {name}: {exc}")


@app.post("/api/analyze/phenotypes")
async def analyze_phenotypes(
    earth: UploadFile = File(...),
    space: UploadFile = File(...),
    parameters: Optional[str] = Form(None),
):
    earth_df, space_df = _read_upload(earth), _read_upload(space)
    param_list = [p.strip() for p in parameters.split(",")] if parameters else None
    try:
        result = engine.compare_phenotypes(earth_df, space_df, param_list)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return JSONResponse(result.to_dict(orient="records"))


@app.post("/api/analyze/omics")
async def analyze_omics(
    earth: UploadFile = File(...),
    space: UploadFile = File(...),
    data_type: str = Form("transcriptomics"),  # transcriptomics|proteomics|metabolomics
    id_column: Optional[str] = Form(None),
):
    earth_df, space_df = _read_upload(earth), _read_upload(space)
    try:
        result = engine.differential_abundance(earth_df, space_df, id_column)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    payload = {
        "data_type": data_type,
        "n_features": len(result),
        "n_significant": int(result["significant"].sum()),
        "results": result.to_dict(orient="records"),
    }
    if data_type == "metabolomics":
        payload["summary"] = engine.metabolite_summary(result)
    return JSONResponse(payload)


# ---------------------------------------------------------------------------
# Demo (offline sample data)
# ---------------------------------------------------------------------------
def _run_demo() -> Dict:
    data = generate_sample_data()
    pheno = engine.compare_phenotypes(data["earth_phenotypes"], data["space_phenotypes"])
    diff = {
        "transcriptomics": engine.differential_abundance(
            data["earth_transcriptomics"], data["space_transcriptomics"], id_column="gene"),
        "proteomics": engine.differential_abundance(
            data["earth_proteomics"], data["space_proteomics"], id_column="protein"),
        "metabolomics": engine.differential_abundance(
            data["earth_metabolomics"], data["space_metabolomics"], id_column="metabolite"),
    }
    return {"phenotypes": pheno, "omics": diff}


@app.get("/api/analyze/demo")
async def demo():
    out = _run_demo()
    return JSONResponse(summary_payload(out["phenotypes"], out["omics"]))


@app.get("/api/report/demo", response_class=PlainTextResponse)
async def demo_report():
    out = _run_demo()
    return markdown_report(out["phenotypes"], out["omics"],
                           source="ASTRA-BIO built-in demo dataset")
