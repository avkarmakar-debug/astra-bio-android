"""
NASA OSDR Biological Data API client.

Real integration against the public OSDR BDAPI v2:
  Base : https://visualization.osdr.nasa.gov/biodata/api/v2
  REST : /v2/datasets/, /v2/dataset/{accession}/, /v2/dataset/{accession}/files/
  Query: /v2/query/metadata/?..., /v2/query/data/?...

API reference: https://visualization.osdr.nasa.gov/biodata/api/
"""

from __future__ import annotations

import io
import os
from typing import Any, Dict, List, Optional

import httpx
import pandas as pd

OSDR_API_BASE = os.getenv(
    "OSDR_API_BASE", "https://visualization.osdr.nasa.gov/biodata/api/v2"
)
REQUEST_TIMEOUT = 60.0


class OSDRError(Exception):
    """Raised when the OSDR API returns an error or unreachable."""


class OSDRClient:
    """Client for the NASA OSDR Biological Data API (BDAPI v2)."""

    def __init__(self, base_url: str = OSDR_API_BASE, timeout: float = REQUEST_TIMEOUT):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # ------------------------------------------------------------------
    # REST interface (metadata traversal)
    # ------------------------------------------------------------------
    async def list_datasets(self) -> List[Dict[str, Any]]:
        """List all dataset accession numbers in OSDR."""
        data = await self._get_json(f"{self.base_url}/datasets/")
        if isinstance(data, dict):
            return data.get("datasets", data.get("data", []))
        return data

    async def get_dataset_metadata(self, accession: str) -> Dict[str, Any]:
        """Full metadata tree for one dataset, e.g. OSD-48."""
        accession = accession.strip().upper()
        return await self._get_json(f"{self.base_url}/dataset/{accession}/")

    async def get_assays_samples(self, accession: str) -> Dict[str, Any]:
        """Metadata for all assays and all samples in a dataset."""
        accession = accession.strip().upper()
        return await self._get_json(
            f"{self.base_url}/dataset/{accession}/assay/*/sample/*/"
        )

    async def list_files(self, accession: str) -> List[Dict[str, Any]]:
        """File records with direct download URLs for a dataset."""
        accession = accession.strip().upper()
        data = await self._get_json(f"{self.base_url}/dataset/{accession}/files/")
        if isinstance(data, dict):
            return data.get("files", data.get("data", []))
        return data

    # ------------------------------------------------------------------
    # Query interface (metadata + data interrogation, tabular output)
    # ------------------------------------------------------------------
    async def query_metadata(
        self, params: Dict[str, str], fmt: str = "csv"
    ) -> pd.DataFrame:
        """
        Query sample-level metadata. Keys are period-separated field names,
        e.g. {"study.characteristics.organism": "escherichia coli",
              "study.factor value.spaceflight": ""}   # empty = return all values
        """
        return await self._query_table(f"{self.base_url}/query/metadata/", params, fmt)

    async def query_data(
        self, params: Dict[str, str], fmt: str = "csv"
    ) -> pd.DataFrame:
        """
        Query underlying tabular data. Must include file.data type or
        file.file name, e.g. {"id.accession": "OSD-48",
                               "file.data type": "normalized counts"}
        """
        return await self._query_table(f"{self.base_url}/query/data/", params, fmt)

    # ------------------------------------------------------------------
    # Convenience: fetch a flight-vs-ground comparison table for a study
    # ------------------------------------------------------------------
    async def fetch_expression_matrix(
        self,
        accession: str,
        data_type: str = "normalized counts",
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Fetch an expression/abundance matrix plus the sample metadata needed
        to split samples into spaceflight vs ground control groups.

        Returns (matrix_df, metadata_df). Sample names are the join key.
        """
        accession = accession.strip().upper()

        meta = await self.query_metadata(
            {
                "id.accession": accession,
                "study.factor value.spaceflight": "",
                "study.characteristics.organism": "",
                "study.characteristics.strain": "",
            }
        )
        # Skip the optional 2-line header when present
        if str(meta.iloc[0, 0]).lower().startswith(("accession", "#")):
            meta = meta.iloc[1:].reset_index(drop=True)

        matrix = await self.query_data(
            {
                "id.accession": accession,
                "file.data type": data_type,
                "column.*": "",
            }
        )

        return matrix, meta

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------
    async def _query_table(
        self, endpoint: str, params: Dict[str, str], fmt: str
    ) -> pd.DataFrame:
        """Run a query-interface GET and parse the tabular response."""
        query: Dict[str, str] = {}
        for k, v in params.items():
            query[k] = v if v != "" else ""  # key-only component = "return this field"
        # drop empty values so they become bare keys in the query string
        bare = [k for k, v in query.items() if v == ""]
        query = {k: v for k, v in query.items() if v != ""}
        url = httpx.URL(endpoint, params=query)
        if bare:
            url = httpx.URL(str(url) + ("&" if query else "?") + "&".join(bare))
        if fmt != "csv":
            url = httpx.URL(str(url) + ("&" if str(url).find("?") > 0 else "?") + f"format={fmt}")

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                r = await client.get(str(url))
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise OSDRError(f"OSDR query failed: {exc}") from exc

        try:
            return pd.read_csv(io.StringIO(r.text))
        except Exception as exc:
            raise OSDRError(f"Could not parse OSDR tabular response: {exc}") from exc

    async def _get_json(self, url: str) -> Any:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                r = await client.get(url)
                r.raise_for_status()
                return r.json()
        except httpx.HTTPError as exc:
            raise OSDRError(f"OSDR request failed: {exc}") from exc
        except ValueError as exc:
            raise OSDRError(f"OSDR returned non-JSON response: {exc}") from exc
