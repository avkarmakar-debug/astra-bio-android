"""Smoke tests for the ASTRA-BIO API. Run: pytest tests/ -v"""
import io

import pandas as pd
from fastapi.testclient import TestClient

from app.main import app
from app.analysis import ComparativeAnalysisEngine, generate_sample_data

client = TestClient(app)


def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_demo_summary():
    r = client.get("/api/analyze/demo")
    assert r.status_code == 200
    body = r.json()
    assert "phenotypes" in body and "omics" in body
    assert body["omics"]["metabolomics"]["n_features"] > 0


def test_demo_report():
    r = client.get("/api/report/demo")
    assert r.status_code == 200
    assert "ASTRA-BIO Comparative Analysis Report" in r.text


def test_engine_phenotypes():
    engine = ComparativeAnalysisEngine()
    data = generate_sample_data()
    res = engine.compare_phenotypes(data["earth_phenotypes"], data["space_phenotypes"])
    assert len(res) == 3
    mic = res[res.feature == "MIC"].iloc[0]
    assert mic["fold_change"] > 1.2  # space MIC elevated in demo data


def test_engine_proteomics_fdr():
    engine = ComparativeAnalysisEngine()
    data = generate_sample_data()
    res = engine.differential_abundance(
        data["earth_proteomics"], data["space_proteomics"], id_column="protein")
    assert len(res) == 20
    assert res["p_value_adj"].max() <= 1.0
    assert (res["p_value_adj"] >= res["p_value"] - 1e-9).all()


def test_upload_phenotypes():
    csv = "growth_rate,MIC\n0.4,2.0\n0.5,2.2\n0.45,1.9\n"
    r = client.post(
        "/api/analyze/phenotypes",
        files={"earth": ("e.csv", io.BytesIO(csv.encode()), "text/csv"),
               "space": ("s.csv", io.BytesIO(csv.encode()), "text/csv")},
    )
    assert r.status_code == 200
    assert len(r.json()) == 2
