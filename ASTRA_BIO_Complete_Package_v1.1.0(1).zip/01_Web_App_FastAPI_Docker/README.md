# ASTRA-BIO — Comparative Research Engine

A scientific comparative-analysis platform that compares biological measurements
from **spaceflight experiments** with **Earth-based controls** to determine what
changed, by how much, whether it is statistically supported, and what it may mean
biologically.

## Capabilities

| Module | What it does |
|---|---|
| **Research Data Collector** | Ingests CSV/Excel/JSON uploads; queries NASA OSDR live |
| **Comparative Analysis Engine** | t-tests, Mann-Whitney U, Cohen's d, fold change, 95% CI, BH-FDR correction |
| **Omics pipelines** | Transcriptomics, **proteomics**, **metabolomics** differential abundance + PCA |
| **AI Interpretation & Reporting** | Automated pathway notes, markdown reports, JSON summaries |

## NASA OSDR integration (real API)

Live queries against the [OSDR Biological Data API](https://visualization.osdr.nasa.gov/biodata/api/):

```
GET /api/osdr/datasets                    # all dataset accessions
GET /api/osdr/dataset/OSD-48              # full metadata tree
GET /api/osdr/dataset/OSD-48/files        # file records + download URLs
GET /api/osdr/search?organism=...         # sample-level metadata search
```

Direct API example (no app needed):

```bash
curl "https://visualization.osdr.nasa.gov/biodata/api/v2/query/metadata/?study.characteristics.organism=escherichia%20coli&study.factor%20value.spaceflight"
```

## Quick start

### Docker (recommended)

```bash
docker build -t astra-bio .
docker run -p 8000:8000 astra-bio
# open http://localhost:8000
```

or with compose:

```bash
docker compose up --build
```

### Local development

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Tests

```bash
pip install pytest
pytest tests/ -v
```

## API summary

| Endpoint | Description |
|---|---|
| `POST /api/analyze/phenotypes` | Compare scalar measurements between groups (two file uploads) |
| `POST /api/analyze/omics` | Per-feature differential abundance (transcriptomics/proteomics/metabolomics) |
| `GET /api/analyze/demo` | Full demo on built-in sample data |
| `GET /api/report/demo` | Markdown report of the demo analysis |

## Omics data format

Row-oriented matrices — rows = features, columns = samples, one ID column:

```csv
gene,E01,E02,E03,...
katG,0.12,-0.4,0.7,...
sodA,0.55,0.1,-0.2,...
```

Set `id_column` to `gene` / `protein` / `metabolite` accordingly.

## Scientific guardrails

- Spaceflight vs **matched ground control** = the defensible primary comparison.
- Spaceflight vs **present-day Earth** = exploratory only; confounders must be assessed.
- MIC changes alone do **not** establish clinical resistance — use species-specific breakpoints.
- Automated statistics cannot compensate for incompatible experiments, missing
  measurements, or insufficient replicates.

## Project layout

```
app/
  main.py          FastAPI application
  osdr_client.py   NASA OSDR BDAPI v2 client
  analysis.py      statistical engine (pheno + omics)
  report.py        report generation
static/            web UI (vanilla JS + Chart.js)
tests/             pytest smoke tests
Dockerfile
docker-compose.yml
```


## Production deployment with HTTPS (nginx + Let's Encrypt)

Prereqs: a domain name whose **A record points to your server's IP**, and ports 80/443 open.

```bash
cd astra_bio_app
chmod +x scripts/init-letsencrypt.sh

# One-time: get the certificate and start everything
DOMAIN=astra.yourdomain.com EMAIL=you@example.com bash scripts/init-letsencrypt.sh

# After that, normal start/stop is just:
docker compose -f docker-compose.prod.yml up -d
docker compose -f docker-compose.prod.yml down
```

- Certificates are free (Let's Encrypt), valid 90 days, and **renew + reload automatically** —
  certbot checks twice a day, nginx picks up new certs within a minute.
- Test with `STAGING=1` first while you iron out DNS/firewall issues (staging avoids rate limits),
  then rerun without it for the real certificate.
- Everything HTTP is redirected to HTTPS; HSTS and security headers are enabled.

### Simpler alternative: Caddy (one container, self-managing certs)

```bash
DOMAIN=astra.yourdomain.com docker compose -f deploy/docker-compose.caddy.yml up -d
```

### Installing on Android (PWA)

Once the app is live at `https://astra.yourdomain.com`: open it in Chrome on the phone →
**Install app** (or ⋮ menu → Add to Home screen). It launches fullscreen with its own icon.

See "Quick start" above for local/Docker development.
