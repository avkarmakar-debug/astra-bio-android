function showTab(id) {
  document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(s => s.classList.remove('active'));
  document.querySelector(`.tab[onclick="showTab('${id}')"]`).classList.add('active');
  document.getElementById(id).classList.add('active');
}

function fmtTable(rows, sigCol = 'significant') {
  if (!rows || !rows.length) return '<p>No results.</p>';
  const cols = Object.keys(rows[0]);
  let html = '<table><tr>' + cols.map(c => `<th>${c}</th>`).join('') + '</tr>';
  for (const r of rows) {
    html += '<tr>' + cols.map(c => {
      let v = r[c];
      if (typeof v === 'number') v = Math.abs(v) < 0.01 ? v.toExponential(2) : v.toFixed(3);
      let cls = '';
      if (c === sigCol && r[c]) cls = (r.log2_fold_change ?? r.difference ?? 0) > 0 ? 'sig-up' : 'sig-dn';
      return `<td class="${cls}">${v}</td>`;
    }).join('') + '</tr>';
  }
  return html + '</table>';
}

async function runDemo() {
  const btn = document.getElementById('run-demo');
  btn.disabled = true; btn.textContent = 'Running…';
  try {
    const r = await fetch('/api/analyze/demo');
    const data = await r.json();
    const el = document.getElementById('demo-results');
    let html = `<h3>Phenotypes</h3>${fmtTable(data.phenotypes)}`;
    for (const [k, v] of Object.entries(data.omics)) {
      html += `<h3>${k} — ${v.n_significant}/${v.n_features} significant</h3>`;
      html += fmtTable(v.top_hits.filter(h => h.p_value_adj < 0.05).concat(v.top_hits.filter(h => h.p_value_adj >= 0.05)).slice(0, 8));
    }
    el.innerHTML = html;
    plotPheno(data.phenotypes);
  } catch (e) {
    document.getElementById('demo-results').innerHTML = `<pre>Error: ${e}</pre>`;
  }
  btn.disabled = false; btn.textContent = '▶ Run Full Demo';
}

let chart;
function plotPheno(rows) {
  const ctx = document.getElementById('pheno-chart');
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: rows.map(r => r.feature),
      datasets: [
        { label: 'Earth mean', data: rows.map(r => r.earth_mean), backgroundColor: '#1f6feb' },
        { label: 'Space mean', data: rows.map(r => r.space_mean), backgroundColor: '#f85149' }
      ]
    },
    options: { plugins: { title: { display: true, text: 'Phenotype Means: Earth vs Spaceflight' } } }
  });
}

async function analyzePheno() {
  const fd = new FormData();
  fd.append('earth', document.getElementById('ph-earth').files[0]);
  fd.append('space', document.getElementById('ph-space').files[0]);
  const p = document.getElementById('ph-params').value;
  if (p) fd.append('parameters', p);
  const r = await fetch('/api/analyze/phenotypes', { method: 'POST', body: fd });
  const data = await r.json();
  document.getElementById('upload-results').innerHTML =
    r.ok ? `<h3>Phenotype Results</h3>${fmtTable(data)}` : `<pre>${JSON.stringify(data, null, 2)}</pre>`;
}

async function analyzeOmics() {
  const fd = new FormData();
  fd.append('earth', document.getElementById('om-earth').files[0]);
  fd.append('space', document.getElementById('om-space').files[0]);
  fd.append('data_type', document.getElementById('om-type').value);
  const idc = document.getElementById('om-id').value;
  if (idc) fd.append('id_column', idc);
  const r = await fetch('/api/analyze/omics', { method: 'POST', body: fd });
  const data = await r.json();
  document.getElementById('upload-results').innerHTML =
    r.ok ? `<h3>${data.data_type}: ${data.n_significant}/${data.n_features} significant</h3>${fmtTable(data.results)}`
         : `<pre>${JSON.stringify(data, null, 2)}</pre>`;
}

async function osdrMetadata() {
  const acc = document.getElementById('osdr-acc').value.trim();
  const r = await fetch(`/api/osdr/dataset/${encodeURIComponent(acc)}`);
  document.getElementById('osdr-results').innerHTML = `<pre>${JSON.stringify(await r.json(), null, 2).slice(0, 8000)}</pre>`;
}
async function osdrFiles() {
  const acc = document.getElementById('osdr-acc').value.trim();
  const r = await fetch(`/api/osdr/dataset/${encodeURIComponent(acc)}/files`);
  const data = await r.json();
  const files = data.files || [];
  document.getElementById('osdr-results').innerHTML =
    `<h3>${files.length} files</h3>` + fmtTable(files.map(f => ({
      name: f.filename || f['file name'] || JSON.stringify(f).slice(0, 80),
      datatype: f['data type'] || f.datatype || '',
      url: (f.url || f.download_url || '').slice(0, 90)
    })));
}
async function osdrSearch() {
  const org = document.getElementById('osdr-org').value.trim();
  const r = await fetch(`/api/osdr/search?organism=${encodeURIComponent(org)}`);
  const data = await r.json();
  document.getElementById('osdr-results').innerHTML =
    `<h3>${data.n_samples} matching samples</h3>` + fmtTable(data.preview, '___none');
}
