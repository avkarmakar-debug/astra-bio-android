#!/usr/bin/env python3
"""
ASTRA-BIO: Comparative Research Engine
Working Prototype v1.0.0

A scientific comparative analysis application for spaceflight vs Earth biology.
"""

import pandas as pd
import numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Set plotting style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")


class AstraBioCollector:
    """
    Application 1: Research Data Collector
    Handles data ingestion from various sources
    """

    def __init__(self):
        self.datasets = {}
        self.metadata = {}

    def load_from_file(self, filepath: str, source_type: str = "auto") -> Dict:
        """Load data from CSV, Excel, or JSON"""
        if filepath.endswith('.csv'):
            df = pd.read_csv(filepath)
        elif filepath.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(filepath)
        elif filepath.endswith('.json'):
            df = pd.read_json(filepath)
        else:
            raise ValueError("Unsupported file format")

        dataset_id = f"dataset_{len(self.datasets)}"
        self.datasets[dataset_id] = df
        self.metadata[dataset_id] = {
            'source': filepath,
            'rows': len(df),
            'columns': list(df.columns),
            'source_type': source_type
        }

        return {'dataset_id': dataset_id, 'data': df}

    def create_sample_data(self) -> Dict:
        """Create realistic sample spaceflight vs Earth data"""
        np.random.seed(42)
        n_samples = 30

        # Earth control group
        earth_growth = np.random.normal(0.45, 0.08, n_samples)
        earth_mic = np.random.normal(2.0, 0.3, n_samples)
        earth_biofilm = np.random.normal(0.35, 0.06, n_samples)

        # Spaceflight group
        space_growth = np.random.normal(0.38, 0.09, n_samples)
        space_mic = np.random.normal(3.2, 0.5, n_samples)
        space_biofilm = np.random.normal(0.52, 0.08, n_samples)

        # Gene expression
        genes = ['katG', 'sodA', 'recA', 'lexA', 'ompF', 'acrA', 'marR', 'soxR']
        earth_expression = np.random.normal(0, 0.5, (n_samples, len(genes)))
        space_expression = np.random.normal(0.8, 0.7, (n_samples, len(genes)))

        # Create DataFrames
        earth_df = pd.DataFrame({
            'sample_id': [f'Earth_{i:03d}' for i in range(n_samples)],
            'growth_rate': earth_growth,
            'MIC': earth_mic,
            'biofilm_biomass': earth_biofilm,
            'condition': 'Earth_Control'
        })

        space_df = pd.DataFrame({
            'sample_id': [f'Space_{i:03d}' for i in range(n_samples)],
            'growth_rate': space_growth,
            'MIC': space_mic,
            'biofilm_biomass': space_biofilm,
            'condition': 'Spaceflight'
        })

        earth_expr_df = pd.DataFrame(earth_expression, columns=genes)
        earth_expr_df['condition'] = 'Earth_Control'
        earth_expr_df['sample_id'] = [f'Earth_{i:03d}' for i in range(n_samples)]

        space_expr_df = pd.DataFrame(space_expression, columns=genes)
        space_expr_df['condition'] = 'Spaceflight'
        space_expr_df['sample_id'] = [f'Space_{i:03d}' for i in range(n_samples)]

        self.datasets = {
            'earth_phenotypes': earth_df,
            'space_phenotypes': space_df,
            'earth_expression': earth_expr_df,
            'space_expression': space_expr_df
        }

        return self.datasets


class AstraBioAnalyzer:
    """
    Application 2: Comparative Analysis Engine
    Performs statistical comparisons and calculates effect sizes
    """

    def __init__(self):
        self.results = {}

    def compare_groups(self, earth_data: np.ndarray, space_data: np.ndarray, 
                       parameter_name: str) -> Dict:
        """Comprehensive statistical comparison between two groups"""
        earth_mean = np.mean(earth_data)
        space_mean = np.mean(space_data)
        earth_std = np.std(earth_data, ddof=1)
        space_std = np.std(space_data, ddof=1)

        # Effect size (Cohen's d)
        pooled_std = np.sqrt(((len(earth_data)-1)*earth_std**2 + 
                             (len(space_data)-1)*space_std**2) / 
                            (len(earth_data) + len(space_data) - 2))
        cohens_d = (space_mean - earth_mean) / pooled_std

        # Fold change and percentage
        fold_change = space_mean / earth_mean if earth_mean != 0 else np.nan
        pct_change = ((space_mean - earth_mean) / earth_mean) * 100 if earth_mean != 0 else np.nan

        # Statistical tests
        t_stat, p_value = stats.ttest_ind(space_data, earth_data)
        u_stat, p_value_mw = stats.mannwhitneyu(space_data, earth_data, alternative='two-sided')

        # Confidence interval
        diff = space_mean - earth_mean
        se_diff = pooled_std * np.sqrt(1/len(earth_data) + 1/len(space_data))
        ci_95 = stats.t.interval(0.95, len(earth_data)+len(space_data)-2, 
                                loc=diff, scale=se_diff)

        # Interpretation
        if abs(cohens_d) < 0.2:
            effect_size = "Negligible"
        elif abs(cohens_d) < 0.5:
            effect_size = "Small"
        elif abs(cohens_d) < 0.8:
            effect_size = "Medium"
        else:
            effect_size = "Large"

        significance = "Significant" if p_value < 0.05 else "Not significant"

        result = {
            'parameter': parameter_name,
            'earth_mean': earth_mean,
            'earth_std': earth_std,
            'space_mean': space_mean,
            'space_std': space_std,
            'difference': diff,
            'fold_change': fold_change,
            'pct_change': pct_change,
            'cohens_d': cohens_d,
            'effect_size': effect_size,
            't_statistic': t_stat,
            'p_value': p_value,
            'p_value_mannwhitney': p_value_mw,
            'ci_95_lower': ci_95[0],
            'ci_95_upper': ci_95[1],
            'significance': significance,
            'n_earth': len(earth_data),
            'n_space': len(space_data)
        }

        self.results[parameter_name] = result
        return result

    def analyze_phenotypes(self, earth_df: pd.DataFrame, space_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze all phenotype parameters"""
        parameters = ['growth_rate', 'MIC', 'biofilm_biomass']
        results_list = []

        for param in parameters:
            if param in earth_df.columns and param in space_df.columns:
                result = self.compare_groups(
                    earth_df[param].values,
                    space_df[param].values,
                    param
                )
                results_list.append(result)

        return pd.DataFrame(results_list)

    def analyze_gene_expression(self, earth_expr: pd.DataFrame, 
                               space_expr: pd.DataFrame) -> pd.DataFrame:
        """Differential gene expression analysis"""
        gene_columns = [col for col in earth_expr.columns 
                       if col not in ['condition', 'sample_id']]

        results_list = []

        for gene in gene_columns:
            earth_vals = earth_expr[gene].values
            space_vals = space_expr[gene].values

            earth_mean = np.mean(earth_vals)
            space_mean = np.mean(space_vals)
            log2fc = np.log2(space_mean / earth_mean) if earth_mean > 0 else 0

            t_stat, p_val = stats.ttest_ind(space_vals, earth_vals)

            pooled_std = np.sqrt((np.var(earth_vals, ddof=1) + np.var(space_vals, ddof=1)) / 2)
            cohens_d = (space_mean - earth_mean) / pooled_std if pooled_std > 0 else 0

            results_list.append({
                'gene': gene,
                'log2_fold_change': log2fc,
                'earth_mean': earth_mean,
                'space_mean': space_mean,
                't_statistic': t_stat,
                'p_value': p_val,
                'cohens_d': cohens_d,
                'significant': p_val < 0.05,
                'upregulated': log2fc > 0 and p_val < 0.05,
                'downregulated': log2fc < 0 and p_val < 0.05
            })

        # Multiple testing correction
        pvals = [r['p_value'] for r in results_list]
        _, pvals_corrected, _, _ = multipletests(pvals, method='fdr_bh')

        for i, result in enumerate(results_list):
            result['p_value_adj'] = pvals_corrected[i]
            result['significant_adj'] = pvals_corrected[i] < 0.05

        return pd.DataFrame(results_list)


class AstraBioVisualizer:
    """Visualization module for ASTRA-BIO"""

    @staticmethod
    def plot_phenotype_comparison(earth_df: pd.DataFrame, space_df: pd.DataFrame,
                                  parameter: str, ax=None, analyzer=None):
        """Create comparison plot for a phenotype parameter"""
        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 6))

        earth_data = earth_df[parameter]
        space_data = space_df[parameter]

        bp = ax.boxplot([earth_data, space_data], 
                       labels=['Earth Control', 'Spaceflight'],
                       patch_artist=True,
                       widths=0.6)

        bp['boxes'][0].set_facecolor('#3498db')
        bp['boxes'][1].set_facecolor('#e74c3c')

        x_earth = np.random.normal(1, 0.04, size=len(earth_data))
        x_space = np.random.normal(2, 0.04, size=len(space_data))
        ax.scatter(x_earth, earth_data, alpha=0.6, s=50, color='#2980b9', edgecolors='black')
        ax.scatter(x_space, space_data, alpha=0.6, s=50, color='#c0392b', edgecolors='black')

        if analyzer and parameter in analyzer.results:
            result = analyzer.results[parameter]
            ax.text(0.5, 0.95, 
                   f"Fold Change: {result['fold_change']:.2f}\n"
                   f"p-value: {result['p_value']:.2e}\n"
                   f"Cohen's d: {result['cohens_d']:.2f}",
                   transform=ax.transAxes, fontsize=10,
                   verticalalignment='top',
                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

        ax.set_ylabel(parameter.replace('_', ' ').title(), fontsize=12, fontweight='bold')
        ax.set_title(f'{parameter.replace("_", " ").title()} Comparison', 
                    fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)

        return ax

    @staticmethod
    def plot_volcano(expression_results: pd.DataFrame, ax=None):
        """Create volcano plot for gene expression"""
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 7))

        expression_results['neg_log10_p'] = -np.log10(expression_results['p_value'])

        colors = []
        for _, row in expression_results.iterrows():
            if row['significant_adj'] and row['log2_fold_change'] > 0:
                colors.append('red')
            elif row['significant_adj'] and row['log2_fold_change'] < 0:
                colors.append('blue')
            else:
                colors.append('gray')

        ax.scatter(expression_results['log2_fold_change'], 
                  expression_results['neg_log10_p'],
                  c=colors, alpha=0.7, s=100, edgecolors='black')

        for _, row in expression_results.iterrows():
            ax.annotate(row['gene'], 
                       (row['log2_fold_change'], row['neg_log10_p']),
                       textcoords="offset points", xytext=(5, 5),
                       fontsize=9, fontweight='bold')

        ax.axhline(y=-np.log10(0.05), color='green', linestyle='--', alpha=0.5, label='p=0.05')
        ax.axvline(x=0, color='black', linestyle='-', alpha=0.3)

        ax.set_xlabel('Log2 Fold Change', fontsize=12, fontweight='bold')
        ax.set_ylabel('-Log10(p-value)', fontsize=12, fontweight='bold')
        ax.set_title('Volcano Plot: Differential Gene Expression', 
                    fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)

        return ax


class AstraBioReporter:
    """
    Application 3: AI Biological Interpretation and Reporting
    Generates automated interpretations and comprehensive reports
    """

    def __init__(self):
        self.report_sections = []

    def interpret_phenotype(self, result: Dict) -> str:
        """Generate biological interpretation for phenotype results"""
        param = result['parameter']
        direction = "increased" if result['difference'] > 0 else "decreased"
        magnitude = abs(result['pct_change'])

        interpretations = {
            'growth_rate': f"Growth rate {direction} by {magnitude:.1f}% in spaceflight conditions.",
            'MIC': f"MIC {direction} by {magnitude:.1f}% (from {result['earth_mean']:.2f} to {result['space_mean']:.2f} μg/mL).",
            'biofilm_biomass': f"Biofilm biomass {direction} by {magnitude:.1f}% under spaceflight conditions."
        }

        return interpretations.get(param, f"Parameter {param} showed a {magnitude:.1f}% {direction}.")

    def generate_report(self, phenotype_results: pd.DataFrame, 
                       expression_results: pd.DataFrame) -> str:
        """Generate comprehensive analysis report"""

        report = f"""# ASTRA-BIO Comparative Analysis Report
Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## Executive Summary

This report presents a comparative analysis of microbial samples exposed to 
spaceflight conditions versus Earth-based controls.

### Key Findings:

"""

        # Add phenotype summaries
        for _, row in phenotype_results.iterrows():
            direction = "↑" if row['difference'] > 0 else "↓"
            report += f"- **{row['parameter'].replace('_', ' ').title()}**: "
            report += f"{direction} {abs(row['pct_change']):.1f}% "
            report += f"(p = {row['p_value']:.2e}, Cohen's d = {row['cohens_d']:.2f})\n"

        # Add expression summary
        sig_genes = expression_results[expression_results['significant_adj'] == True]
        report += f"\n### Gene Expression:\n"
        report += f"- **{len(sig_genes)} significantly differentially expressed genes**\n"

        return report


def main():
    """Main execution function"""
    print("=" * 70)
    print("ASTRA-BIO: Comparative Research Engine v1.0.0")
    print("=" * 70)

    # Initialize components
    collector = AstraBioCollector()
    analyzer = AstraBioAnalyzer()
    visualizer = AstraBioVisualizer()
    reporter = AstraBioReporter()

    # Load sample data
    print("\n[1/4] Loading sample data...")
    data = collector.create_sample_data()

    # Run analysis
    print("\n[2/4] Running comparative analysis...")
    phenotype_results = analyzer.analyze_phenotypes(
        data['earth_phenotypes'],
        data['space_phenotypes']
    )

    expression_results = analyzer.analyze_gene_expression(
        data['earth_expression'],
        data['space_expression']
    )

    # Display results
    print("\n" + "=" * 70)
    print("PHENOTYPE COMPARISON RESULTS")
    print("=" * 70)
    print(phenotype_results[['parameter', 'earth_mean', 'space_mean', 
                            'fold_change', 'pct_change', 'cohens_d', 
                            'p_value', 'significance']].to_string(index=False))

    print("\n" + "=" * 70)
    print("GENE EXPRESSION RESULTS")
    print("=" * 70)
    print(expression_results[['gene', 'log2_fold_change', 'p_value', 
                             'p_value_adj', 'significant_adj']].to_string(index=False))

    # Generate visualizations
    print("\n[3/4] Generating visualizations...")
    fig = plt.figure(figsize=(16, 12))

    ax1 = plt.subplot(2, 2, 1)
    visualizer.plot_phenotype_comparison(data['earth_phenotypes'],
                                        data['space_phenotypes'],
                                        'growth_rate', ax1, analyzer)

    ax2 = plt.subplot(2, 2, 2)
    visualizer.plot_phenotype_comparison(data['earth_phenotypes'],
                                        data['space_phenotypes'],
                                        'MIC', ax2, analyzer)

    ax3 = plt.subplot(2, 2, 3)
    visualizer.plot_phenotype_comparison(data['earth_phenotypes'],
                                        data['space_phenotypes'],
                                        'biofilm_biomass', ax3, analyzer)

    ax4 = plt.subplot(2, 2, 4)
    visualizer.plot_volcano(expression_results, ax4)

    plt.tight_layout()
    plt.savefig('astra_bio_analysis.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: astra_bio_analysis.png")

    # Generate report
    print("\n[4/4] Generating report...")
    report = reporter.generate_report(phenotype_results, expression_results)

    with open('astra_bio_report.md', 'w') as f:
        f.write(report)
    print("✓ Saved: astra_bio_report.md")

    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)
    print("\nKey Findings:")
    for _, row in phenotype_results.iterrows():
        direction = "↑" if row['difference'] > 0 else "↓"
        print(f"  {direction} {row['parameter']}: {abs(row['pct_change']):.1f}% change")

    sig_genes = expression_results[expression_results['significant_adj'] == True]
    print(f"\n  Differentially expressed genes: {len(sig_genes)}")
    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
